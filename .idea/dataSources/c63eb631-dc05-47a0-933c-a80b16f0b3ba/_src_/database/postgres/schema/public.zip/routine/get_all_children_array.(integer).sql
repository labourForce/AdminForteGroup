create function get_all_children_array(use_parent integer) returns integer[]
LANGUAGE plpgsql
AS $$
DECLARE
    process_parents INT4[] := ARRAY[ use_parent ];
    children INT4[] := '{}';
    new_children INT4[];
BEGIN
    WHILE ( array_upper( process_parents, 1 ) IS NOT NULL ) LOOP
        new_children := ARRAY( SELECT category_id FROM electro.category_subcategory WHERE parent_category_id = ANY( process_parents ) AND category_id <> ALL( children ) );
        children := children || new_children;
        process_parents := new_children;
    END LOOP;
    RETURN children;
END;
$$;
